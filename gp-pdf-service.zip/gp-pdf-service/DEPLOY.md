# GrandPride PDF Service — Deploy to Render (free)

This service fills your leasing DOCX template and returns a real PDF. The Telegram bot calls it.

## What's in this folder
- `server.js` — the service
- `template.docx` — YOUR leasing template (the one with {{placeholders}})
- `Dockerfile` — installs LibreOffice
- `package.json`

## Deploy steps (~10 min, one time)

### 1. Put this folder on GitHub
- Create a new **private** GitHub repo, e.g. `gp-pdf-service`
- Upload all files in this folder to it (via GitHub Desktop or the web "upload files")

### 2. Create the Render service
1. Go to **https://render.com** → sign up / log in (free)
2. Click **New +** → **Web Service**
3. Connect your GitHub, pick the `gp-pdf-service` repo
4. Settings:
   - **Runtime / Environment:** Docker
   - **Instance type:** Free
   - **Region:** Singapore (closest to Malaysia)
5. Add an **Environment Variable**:
   - Key: `SHARED_SECRET`  Value: `gp-pdf-9f3k2p`
6. Click **Create Web Service**. Wait ~5 min for it to build (installs LibreOffice).

### 3. Get the URL
- When live, Render shows a URL like `https://gp-pdf-service.onrender.com`
- Open it in a browser — you should see `GrandPride PDF service OK`
- **Send me that URL** — I'll wire the Telegram bot to it.

## Notes
- Render free tier **sleeps after 15 min idle**; the first request after sleeping takes ~30–50s to wake (the bot will say "generating…"). Subsequent ones are fast.
- To update the template later: replace `template.docx` in the repo and push — Render redeploys automatically.
