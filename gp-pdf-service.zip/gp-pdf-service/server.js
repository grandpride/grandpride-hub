// GrandPride agreement PDF service
// Fills the leasing DOCX template with values, converts to PDF via LibreOffice,
// returns the PDF. Runs on Render free tier (Docker with LibreOffice).

const express = require('express');
const { execFile } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const PizZip = require('pizzip');

const app = express();
app.use(express.json({ limit: '5mb' }));

const TEMPLATE_PATH = path.join(__dirname, 'template.docx');
const SHARED_SECRET = process.env.SHARED_SECRET || 'gp-pdf-9f3k2p';

function fillDocx(templateBuf, values){
  const zip = new PizZip(templateBuf);
  // replace {{key}} in every xml part (document, headers, footer)
  Object.keys(zip.files).forEach(function(name){
    if(!name.endsWith('.xml')) return;
    let xml = zip.files[name].asText();
    xml = xml.replace(/\{\{([a-z_0-9]+)\}\}/g, function(m, key){
      var v = values[key];
      if(v===undefined || v===null) v = '';
      // basic XML escaping
      return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    });
    zip.file(name, xml);
  });
  return zip.generate({ type: 'nodebuffer' });
}

function libreConvert(docxPath, outDir){
  return new Promise(function(resolve, reject){
    // use a unique profile dir so concurrent conversions don't clash
    const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'lo-'));
    execFile('libreoffice', [
      '--headless','--norestore','--nolockcheck',
      '-env:UserInstallation=file://'+profile,
      '--convert-to','pdf','--outdir', outDir, docxPath
    ], { timeout: 60000 }, function(err, stdout, stderr){
      try{ fs.rmSync(profile, { recursive:true, force:true }); }catch(e){}
      if(err){ reject(new Error('convert failed: '+(stderr||err.message))); return; }
      const pdf = docxPath.replace(/\.docx$/i, '.pdf');
      if(!fs.existsSync(pdf)){ reject(new Error('pdf not produced')); return; }
      resolve(pdf);
    });
  });
}

app.get('/', function(req,res){ res.send('GrandPride PDF service OK'); });

app.post('/generate', async function(req, res){
  try{
    if((req.headers['x-secret']||'') !== SHARED_SECRET){ res.status(401).json({error:'unauthorized'}); return; }
    const values = req.body && req.body.values ? req.body.values : {};
    if(!fs.existsSync(TEMPLATE_PATH)){ res.status(500).json({error:'template missing on server'}); return; }
    const tpl = fs.readFileSync(TEMPLATE_PATH);
    const filled = fillDocx(tpl, values);

    const work = fs.mkdtempSync(path.join(os.tmpdir(), 'gp-'));
    const docxPath = path.join(work, 'agreement.docx');
    fs.writeFileSync(docxPath, filled);
    const pdfPath = await libreConvert(docxPath, work);
    const pdf = fs.readFileSync(pdfPath);
    try{ fs.rmSync(work, { recursive:true, force:true }); }catch(e){}

    const name = (req.body && req.body.filename) ? String(req.body.filename).replace(/[^a-zA-Z0-9._-]/g,'_') : 'agreement.pdf';
    res.setHeader('Content-Type','application/pdf');
    res.setHeader('Content-Disposition','attachment; filename="'+name+'"');
    res.send(pdf);
  }catch(e){
    res.status(500).json({ error: (e && e.message) || String(e) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, function(){ console.log('GP PDF service on :'+PORT); });
